Remember it's my personal notes, if somebody can make sense to it :).

But the .CSX file can be useful you can use CheatEngine Dissect Structure and checkout some resource's in memory struct layout.